module HighScoresHelper
end
