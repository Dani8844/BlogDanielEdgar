# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Project::Application.config.secret_token = '7b55284736e43be384a85a529be0837a52b39a7d80f48c685a2f81f821f502b3784aeb288bcf5f90e2db2e0264ae32b29a427b527d65c7addb22d04d4771711c'
