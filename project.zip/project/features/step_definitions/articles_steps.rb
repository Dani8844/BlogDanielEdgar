Given /^an article with the title "([^"]*)"$/ do |arg1|
  
   @articulonum1 = Article.create(:title=>arg1)
end

When /^I am on the articles page$/ do
  visit Article_url
end

Then /^I should see "([^"]*)"$/ do |arg1|
   @articulonum1.title.should == arg1
end


Given /^an article with the title "([^"]*)" and the content "([^"]*)"$/ do |arg1, arg2|
  @articulonum3.title.should == arg1
  @articulonum3.content.should == arg2
  
end

When /^I follow "([^"]*)"$/ do |arg1|
   visit Article_url
   click_link arg1
end





